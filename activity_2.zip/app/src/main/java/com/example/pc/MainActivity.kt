package com.example.pc

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text

private const val key = "key"
private const val color = "color"

class MainActivity : AppCompatActivity() {
    private lateinit var temp: TextView
    private lateinit var text1: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("MainActivity", "onCreate() is called")
        temp = findViewById(com.example.pc.R.id.textView)
        text1 = findViewById(com.example.pc.R.id.textView1)
        val bt1: Button = findViewById<Button>(R.id.button1)
        bt1.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt1.text
        }
        val bt2: Button = findViewById<Button>(R.id.button2)
        bt2.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt2.text
        }
        val bt3: Button = findViewById<Button>(R.id.button3)
        bt3.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt3.text
        }
        val bt4: Button = findViewById<Button>(R.id.button4)
        bt4.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt4.text
        }
        val bt5: Button = findViewById<Button>(R.id.button5)
        bt5.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt5.text
        }
        val bt6: Button = findViewById<Button>(R.id.button6)
        bt6.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt6.text
        }
        val bt7: Button = findViewById<Button>(R.id.button7)
        bt7.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt7.text
        }
        val bt8: Button = findViewById<Button>(R.id.button8)
        bt8.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt8.text
        }
        val bt9: Button = findViewById<Button>(R.id.button9)
        bt9.setOnClickListener {
            temp.text=""
            text1.text = text1.text.toString()+bt9.text
        }
        val bt10: Button = findViewById<Button>(R.id.button11)
        bt10.setOnClickListener {
            text1.text = text1.text.toString()+bt10.text
        }
        val bt11: Button = findViewById<Button>(R.id.button10)
        bt11.setOnClickListener {
            temp.text=""
            val size = text1.text.length
            text1.text = text1.text.substring(0, size-1).toString()
        }
        val bt12: Button = findViewById<Button>(R.id.button12)
        bt12.setOnClickListener {
            val txt = text1.text.toString()
            if (txt == "1567") {
                text1.setTextColor(resources.getColor(R.color.green))
                Toast.makeText(this, "Password is correct", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, NextActivity::class.java)
                startActivity(intent)
            } else {
                text1.setTextColor(resources.getColor(R.color.red))
                Toast.makeText(this, "Password is wrong", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(key, text1.text.toString())
        outState.putInt(color, text1.currentTextColor)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        text1.text = savedInstanceState.getString(key)
        text1.setTextColor(savedInstanceState.getInt(color))
        if (text1.text.toString().isNotEmpty()){
            temp.text = ""
        }
    }
}